const { promisify} = require('util');
const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');

module.exports = {
    writeFile: (data) => {
        //异步方法
        fs.writeFile('./message.txt', data,function(err){
            if(err) 
                console.log('写文件操作失败');
            else 
                console.log('写文件操作成功');
        });
    },
    writeBean:  promisify((data, callback) => {
        fs.exists(data.url)
        // 创建文件夹 url
        const dataFolder  = path.resolve(__dirname, `../../data/`);
        if (!fs.existsSync(dataFolder)) {
            fs.mkdirSync(dataFolder);
            console.log(`mkdir ${dataFolder}`);
        }
        const folder  = path.resolve(__dirname, `../../data/${data.url}/`);
        if (!fs.existsSync(folder)) {
            fs.mkdirSync(folder);
            console.log(`mkdir ${folder}`);
        } else {
            console.log(`direct close ${folder}`);
            callback();
            rreturn; 
        }

        // 写入相关信息到txt
        const fileName = `${folder}/bean.txt`;
        fs.writeFileSync(fileName, JSON.stringify(data));
        // 下载图片
        const pics = data.pics;
        pics.forEach(async src => {
            await ulrToImg(src, folder);
        });
        callback();
    })
    
}

const ulrToImg = promisify((url, dir, callback) => {
    const mod = /^https:/.test(url) ? https : http;
    let ext = path.extname(url);

    mod.get(url, res => {
        if (ext === null || ext === '' || ext.length >4) {
            // 未得到扩展名,从header取
            const contentType = res.headers['content-type'];
            ext = contentType.split('/')[1];
            if (ext === 'jpeg') {
                ext = 'jpg';
            }
        }
        const file = path.join(dir, `${Date.now()}${ext}`);

        res.pipe(fs.createWriteStream(file))
        .on('finish', () => {
            callback();
            console.log(file);
        })
    });
})