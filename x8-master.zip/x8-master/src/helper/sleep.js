const { promisify} = require('util');

module.exports = promisify((timelong, callback)=>{
    setTimeout(function() {
        callback();
        console.log('time out');
    }, timelong);
});

// function later(delay, value) {
//     return new Promise(function(resolve) {
//         setTimeout(resolve, delay, value); // Note the order, `delay` before `value`
//         /* Or for outdated browsers that don't support doing that:
//         setTimeout(function() {
//             resolve(value);
//         }, delay);
//         Or alternately:
//         setTimeout(resolve.bind(null, value), delay);
//         */
//     });
// }