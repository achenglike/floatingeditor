const path = require('path');

module.exports = {
    mn: path.resolve(__dirname, '../../mn'),
    host: '8xxapp.com',
    path: 'http://8xxapp.com/forum-798-1.html',
    cookie: '',
    userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36'
}