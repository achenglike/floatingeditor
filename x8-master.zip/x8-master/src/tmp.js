const sleep = require('./helper/sleep');
const async = require('async');

(async () => {
    const x = [1,2,3,4,5]
    for(let value of x) {
        await sleep(2000);
    }
})()