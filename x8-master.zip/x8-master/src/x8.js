const puppeteer = require('puppeteer');
const config = require('./config/default');
const { writeFile, writeBean } = require('./helper/writefile');
const sleep = require('./helper/sleep');


(async () => {

    const DELAY_OPTIONS = {
        waitUntil: 'networkidle',
        timeout: 0
    }

    // 初始化puppeteer
    const browser = await puppeteer.launch({headless: true});
    // 获取所有列表页URLs
    const listUrls = await allUrls(browser, config,  config.path);
    // 获取详情页URLs
    let beanUrls = [];
    // 中止条件
    const pageCount = config.limitPage; let indexPage = 0;
    // const beanUrls = await detailUrls(browser, config, listUrls[0]);
    for(let url of listUrls) {
        if (pageCount!=0 && pageCount === indexPage) {
            break;
        }
        indexPage++;

        let tmp = await detailUrls(browser, config, url);
        console.log(tmp);
        beanUrls = [...beanUrls, ...tmp];
        console.log(`bean url size:${beanUrls.length}`);
        await sleep(30000);
    }

    // 获取详情数据
    for(let url of beanUrls) {
        const bean = await getDetail(browser, config, url);
        // console.log(bean);
        console.log(url);
        await sleep(30000);
    }
    browser.close();
    

    // 初始化page页面数据 ua cookie
    async function initPage(page, cookieString, userAgentString, domain) {
        await page.setRequestInterceptionEnabled(true);
        page.on('request', request => {
            if (request.resourceType === 'image' ||request.resourceType === 'stylesheet')
                request.abort();
            else {
                request.continue();
            }
              
          });
        await page.setViewport({width: 1920, height: 1080});
        if (cookieString != null && cookieString != "") {
            await setCookie(page, cookieString, domain);
        }
        await page.setUserAgent(userAgentString);
    }

    // 设置cookie的方法
    async function setCookie(page, cookieString, domain) {
        var cookieSplit = cookieString.split(/\s*;\s*/);
    
        const cookieTable = cookieSplit
            .map(token => {
                return token.split("=");
            })
            .reduce((sum, [key, value]) => {
                sum[key] = value;
                return sum;
            }, {});
    
        for (var key in cookieTable) {
            const value = cookieTable[key];
    
            await page.setCookie({
                name: key,
                value: value,
                domain: domain
            });
        }
        //   const cookieList = await page.cookies("https://www.naver.com");
        //   console.dir(cookieList);
    }

    
    // 获取所有列表页面url
    async function allUrls(browser, config, originUrl) {
         // 获取所有列表页URLs
        const page = await browser.newPage();
        console.log("create new page");
        await initPage(page, config.cookie, config.userAgent, config.domain)
        console.log("初始化浏览器页面");

        await page.goto(originUrl, DELAY_OPTIONS);
        const urls = await page.evaluate(() => {
            // http://8xxapp.com/forum-798-217.html
            const lastPage = document.querySelector('a.last').href;
            const r = /forum-\d+-(\d+).html/;
            // 217
            const pageNumbers = r.exec(lastPage)[1];

            let result = [];
            for (var index = 0; index < pageNumbers; index++) {
                result.push(lastPage.replace(pageNumbers, index+1))
            }
            //http://8xxapp.com/forum-798-1.html ... http://8xxapp.com/forum-798-217.html
            return result;
        });

        await page.close();

        return urls;
    }

    // 进入一个列表页，获取全部detail页面的url
    async function detailUrls(browser, config, listUrl) {
        console.log(`抓取详情列表${listUrl}`)

        const page = await browser.newPage();
        await initPage(page, config.cookie, config.userAgent, config.domain)
        // http://8xxapp.com/forum-798-217.html
        await page.goto(listUrl, DELAY_OPTIONS);
        const content = await page.content();
        const r = /<em>\[<a href=".+html" onclick.+class="s xst.+?<\/a>/
        const urls = content.match(/<em>\[<a href=".+html" onclick.+class="s xst.+?<\/a>/g);
        console.log('正则匹配处理');
        await page.close();
        return urls.map((slim) => {
            //<em>[<a href="forum.php?mod=forumdisplay&amp;fid=798&amp;filter=typeid&amp;typeid=5176" target="_blank">旅店</a>]</em> <a href="thread-8845298-1-1.html" onclick="atarget(this)" class="s xst" target="_blank">【ALL/668M】 激情草原完整版 蒙古包内激情抽插小骚货推倒在床用力猛操</a>
            return `http://${config.host}/${/thread.+html/.exec(slim)[0]}`; 
        });

        
    }

    // 提取一个dtail页面的数据
    async function getDetail(browser, config, detailUrl) {
        // http://8xxapp.com/thread-8816903-1-1.html
        console.log(`抓取：${detailUrl}`);

        const page = await browser.newPage();
        await initPage(page, config.cookie, config.userAgent, config.domain);

        await page.goto(detailUrl, DELAY_OPTIONS);
        
                const bean = await page.evaluate(() => {
                    // 提取名称 title
                    const title = document.title;
                    // 提取图片 pics or getAttribute file
                    const pics = Array.prototype.map.call(document.querySelectorAll('img.zoom'), img => img.getAttribute('file'));
        
                    // 提取下载地址   attach
                    let attach;
                    let attachHtml = document.querySelector('ignore_js_op');
                    if (attachHtml != null) {
                        attachHtml = attachHtml.innerHTML;
                        const r = /<a.+href="(\S+)".+>(.+)<\/a>/
                        const attachData = r.exec(attachHtml);
                        console.log(attachData);
                        attach = {
                            href: `http://${document.domain}/${attachData[1]}`,
                            name: attachData[2]
                        }
                    } else {
                        attach = {
                            href: 'catch fail',
                            name: 'catch fail'
                        }
                    }
                        
                    // 记录描述 description
                    let description = document.querySelectorAll('div.t_fsz>table>tbody>tr>td.t_f')[0];
                    if (description === null) {
                        description = 'not found';
                    } else {
                        description = description.innerText;
                    }
                    
                    return {
                        url: document.location.pathname,
                        title: title,
                        pics: pics,
                        attach: attach,
                        description: description.trim()
                    }
                });
        
        await writeBean(bean);
        await page.close();

        return bean;
        
    }
})()